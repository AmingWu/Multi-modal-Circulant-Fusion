#from models import *
#from models.multiatt import model

# You can add more models in this folder. like
# from models.no_question import model
# from models.no_vision_at_all import model
# from models.old_model import model
# from models.bottom_up_top_down import model
# from models.revisiting_vqa_baseline import model
# from models.mlb import model